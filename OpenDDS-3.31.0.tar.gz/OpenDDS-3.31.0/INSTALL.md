# Building and Installing OpenDDS

The content from this file has been moved into the main documention:

- [Read the Docs (latest release)](https://opendds.readthedocs.io/en/latest-release/devguide/building/index.html)
- [Read the Docs (master branch)](https://opendds.readthedocs.io/en/master/devguide/building/index.html)
- [`docs/devguide/building/index.rst` (raw file)](docs/devguide/building/index.rst)
