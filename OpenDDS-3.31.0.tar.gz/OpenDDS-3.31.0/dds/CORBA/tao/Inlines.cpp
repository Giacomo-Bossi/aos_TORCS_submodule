#ifdef ACE_NO_INLINE

#include "tao/CDR.h"
#include "tao/CDR.inl"

#endif
